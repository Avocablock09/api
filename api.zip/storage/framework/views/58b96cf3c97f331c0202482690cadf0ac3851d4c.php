<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
</head>
<body>
    <form action="/jalan" method="POST">
        <label for="name">longitude: </label><input type="text" name="longitude"><br>
        <label for="name">latitude: </label><input type="text" name="latitude"><br>
        <label for="name">status: </label><input type="text" name="status"><br>
        <button type="submit">tambah</button>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\api\resources\views/jalan.blade.php ENDPATH**/ ?>